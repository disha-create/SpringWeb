package com.citiustech.controller;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Component
@RequestMapping("/welcome")
public class WelcomeController {
	
	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView welcome(){
		ModelAndView modelAndView =  new ModelAndView();
		modelAndView.addObject("message","Welcome to Spring Web MVC");
		modelAndView.setViewName("welcome");
		
		
		return modelAndView;
	}
	
	
	@RequestMapping(value="requestParams", method = RequestMethod.GET)
	public ModelAndView showDetails(@RequestParam String username, @RequestParam(required=false, defaultValue="22") int age){
		
		ModelAndView modelAndView =  new ModelAndView();
		modelAndView.addObject("message","Welcome " + username + " your age is " + age);
		modelAndView.setViewName("welcome");
		
		
		return modelAndView;
		
	}
	
	@GetMapping(value="pathParams/{username}/{age}")
	public ModelAndView showPathDetails(@PathVariable String username, @PathVariable String age){
		
		ModelAndView modelAndView =  new ModelAndView();
		modelAndView.addObject("message","Welcome " + username + " your age is " + age);
		modelAndView.setViewName("welcome");
		
		return modelAndView;
		
	}
}