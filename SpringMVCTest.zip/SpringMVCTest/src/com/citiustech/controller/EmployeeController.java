package com.citiustech.controller;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

import com.citiustech.model.Employee;

@Component
@RequestMapping("/employee")
public class EmployeeController {
	
	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView welcome(){
		ModelAndView modelAndView = new ModelAndView();
		Employee employee = new Employee();
		modelAndView.addObject("employee",employee);
		modelAndView.setViewName("employee");
		
		return modelAndView;
	}
	

}
