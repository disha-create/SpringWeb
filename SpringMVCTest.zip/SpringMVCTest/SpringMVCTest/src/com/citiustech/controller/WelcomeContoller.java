package com.citiustech.controller;

import javax.websocket.server.PathParam;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Component
@RequestMapping("/welcome")
public class WelcomeContoller {

	@RequestMapping(method = RequestMethod.GET)
	public ModelAndView welcome(){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("message", "Welcome To Spring WEB MVC");
		modelAndView.setViewName("welcome");
		
		return modelAndView;
	}
	
	@RequestMapping(value="requestParams", method = RequestMethod.GET)
	public ModelAndView showDetails(@RequestParam String username, 
			@RequestParam(required=false, defaultValue="22") int age){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("message", "Welcome " + username + " your age is " + age);
		modelAndView.setViewName("welcome");
		
		return modelAndView;
	}
	
	@GetMapping(value="pathVariable/{username}/{age}")
	public ModelAndView showPathDetails(@PathVariable String username, 
			@PathVariable String age){
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.addObject("message", "Welcome user " + username + " your age is " + age);
		modelAndView.setViewName("welcome");
		
		return modelAndView;
		
	}
	
	//<mvc:annotation-driven />  for @GetMapping
	//http://localhost:9090/SpringMVCTest/mvc/welcome/pathVar/Jack/22
}








