package com.citiustech.controller;

import org.springframework.stereotype.Component;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.citiustech.model.Employee;

@Component
@RequestMapping("/employee")
public class EmployeeController {
	
	@GetMapping
	public ModelAndView initializeEmployee(){
		ModelAndView modelAndView = new ModelAndView();
		Employee employee = new Employee();
		modelAndView.addObject("employee", employee);
		modelAndView.setViewName("employee");
		
		return modelAndView;
	}

	@PostMapping
	public ModelAndView submitEmployee(@ModelAttribute Employee employee){
		ModelAndView modelAndView = new ModelAndView();
		System.out.println(employee);
		Employee defemployee = new Employee();
		modelAndView.addObject("employee", defemployee);
		
		modelAndView.setViewName("employee");
		
		return modelAndView;
	}
}




