package com.citiustech.service;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.citiustech.dao.EmployeeDAO;
import com.citiustech.model.Employee;

//@Component
@Service
public class EmployeeService {
	
	@Autowired
	private EmployeeDAO employeeDAO;

	public void saveEmployee(Employee employee){
		employeeDAO.saveEmployee(employee);
	}
	
	public Collection<Employee> getAllEmloyees(){
		return employeeDAO.getAllEmployees();
	}
}







