package com.citiustech.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.Collection;

import javax.sql.DataSource;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.citiustech.model.Employee;

//@Component
@Repository
public class EmployeeDAO {

	@Autowired
	private DataSource dataSource;
	
	@Autowired
	private JdbcTemplate jdbcTemplate;
	
	@Autowired
	private SessionFactory sessionFactory;
	
	
	@Transactional
	public void saveEmployee(Employee employee){
		//saveUsingJDBC(employee);
		//saveUsingJdbcTemplate(employee);
		//saveUsingHibernate(employee);
		Session session = sessionFactory.getCurrentSession();
		session.persist(employee);
	}
	
	private void saveUsingJDBC(Employee employee){
		try(Connection con = dataSource.getConnection()){
			PreparedStatement pstmt = con.prepareStatement("insert into employeetbl values(?,?,?,?)");
			pstmt.setInt(1, employee.getId());
			pstmt.setString(2, employee.getName());
			pstmt.setString(3, employee.getDesignation());
			pstmt.setDouble(4, employee.getSalary());
			
			pstmt.executeUpdate();
			
			pstmt.close();
		}catch(Exception ex){
			throw new RuntimeException(ex);
		}
	}
	
	private void saveUsingJdbcTemplate(Employee employee){
		jdbcTemplate.update("insert into employeetbl values(?,?,?,?)", new Object[]{
			employee.getId(), 
			employee.getName(),
			employee.getDesignation(),
			employee.getSalary()
		});
	}
	
	public Collection<Employee> getAllEmployees(){
		return jdbcTemplate.query("select id, name, designation, salary from employeetbl", 
				new BeanPropertyRowMapper(Employee.class));
	}
	
	public void saveUsingHibernate(Employee employee){
		Transaction tx = null;
		try{
			Session session = sessionFactory.openSession();
			 tx = session.beginTransaction();
			
			session.persist(employee);
			tx.commit();
			session.close();
		}catch(Exception ex){
			tx.rollback();
			ex.printStackTrace();
		}
		
	}
}













