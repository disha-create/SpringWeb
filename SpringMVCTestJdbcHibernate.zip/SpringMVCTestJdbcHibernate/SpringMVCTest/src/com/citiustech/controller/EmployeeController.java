package com.citiustech.controller;

import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.citiustech.model.Employee;
import com.citiustech.service.EmployeeService;

//@Component
@Controller
@RequestMapping("/employee")
public class EmployeeController {
	
	//private EmployeeService employeeService = new EmployeeService();
	@Autowired
	private EmployeeService employeeService;
	
	@GetMapping
	public ModelAndView initializeEmployee(){
		ModelAndView modelAndView = new ModelAndView();
		Employee employee = new Employee();
		modelAndView.addObject("employee", employee);
		modelAndView.setViewName("employee");
		
		return modelAndView;
	}

	@PostMapping
	public ModelAndView submitEmployee(@ModelAttribute Employee employee){
		ModelAndView modelAndView = new ModelAndView();
		//System.out.println(employee);
		Employee defemployee = new Employee();
		modelAndView.addObject("employee", defemployee);
		
		employeeService.saveEmployee(employee);
		
		modelAndView.setViewName("employee");
		
		return modelAndView;
	}
	
	//http://localhost:9090/SpringMVCTest/mvc/employee/getAllEmps
	@RequestMapping("/getAllEmps")
	public ModelAndView getAllEmployees(){
		ModelAndView modelAndView = new ModelAndView();
		Collection<Employee> emplist = employeeService.getAllEmloyees();
		Employee defEmployee = new Employee();
		modelAndView.addObject("employee", defEmployee);
		modelAndView.addObject("empList", emplist);
		modelAndView.setViewName("employee");
		
		return modelAndView;
	}
}
















